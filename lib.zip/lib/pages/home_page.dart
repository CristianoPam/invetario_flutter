import 'package:flutter/material.dart';


class Homepage extends StatefulWidget {
  const Homepage({super.key});

  @override
  State<Homepage> createState() => _HomepageState();
}

class _HomepageState extends State<Homepage> {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: const Color.fromARGB(255, 231, 219, 219),
      body: Padding(
        padding: const EdgeInsets.all(30),
        //espaçamento de fora
        child: Center(
          child: Form(
           
            child: ListView(
              children: [
                SizedBox(
                  width: 200,
                  height: 200,
                  child: Image.asset('assets/images/logo.png'),
                ),

                const Divider(),

                ButtonTheme( // botão 1
                      height: 60.0,                  
                      child: ElevatedButton(
                      style: ElevatedButton.styleFrom(
                      backgroundColor: const Color.fromARGB(255, 255, 255, 255),                        
                      ),
                      onPressed: () => {
                      },                      
                      child: const Text(
                      "Relatórios",
                      style:  TextStyle(color: Colors.black),                         
                      ),
                      )),

                ButtonTheme( // botão 2
                      height: 60.0,                  
                      child: ElevatedButton(
                      style: ElevatedButton.styleFrom(
                      backgroundColor: const Color.fromARGB(255, 255, 255, 255),                        
                      ),
                      onPressed: () => {
                      },                      
                      child: const Text(
                      "Estoque",
                      style:  TextStyle(color: Colors.black),                         
                      ),
                      )),

                ButtonTheme( // botão 3
                      height: 60.0,                  
                      child: ElevatedButton(
                      style: ElevatedButton.styleFrom(
                      backgroundColor: const Color.fromARGB(255, 255, 255, 255),                        
                      ),
                      onPressed: () => {
                      },                      
                      child: const Text(
                      "Scan QRCode",
                      style:  TextStyle(color: Colors.black),                         
                      ),
                      )),
                
                ButtonTheme( // botão 4
                      height: 60.0,                  
                      child: ElevatedButton(
                      style: ElevatedButton.styleFrom(
                      backgroundColor: const Color.fromARGB(255, 255, 255, 255),                        
                      ),
                      onPressed: () => {
                      },                      
                      child: const Text(
                      "Filiais",
                      style:  TextStyle(color: Colors.black),                         
                      ),
                      )),
                
                ButtonTheme( // botão 5
                      height: 60.0,                  
                      child: ElevatedButton(
                      style: ElevatedButton.styleFrom(
                      backgroundColor: const Color.fromARGB(255, 255, 255, 255),                        
                      ),
                      onPressed: () => {
                      },                      
                      child: const Text(
                      "Configurações",
                      style:  TextStyle(color: Colors.black),                         
                      ),
                      )),

                
                              
          

               

               
              ],
            ),
          ),
        ),
      ),
    );
  }
}